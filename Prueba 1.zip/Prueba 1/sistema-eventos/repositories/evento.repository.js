const db = require('../config/db');

class EventoRepository {
  async obtenerTodas() {
    const [eventos] = await db.query('SELECT * FROM eventos');
    return eventos;
  }

  async crear(evento) {
    const datos = {
      id: evento.id,
      tipo_evento: evento.tipo_evento,
      nombre_evento: evento.nombre_evento,
      nombre_cliente: evento.nombre_cliente,
      fecha: evento.fecha,
      hora: evento.hora,
      detalles: evento.detalles,
      asistentes: evento.asistentes,
      creado_en: evento.creado_en
    };
  
    const [resultado] = await db.query('INSERT INTO eventos SET ?', datos);
    return resultado.insertId;
  }
  

  async obtenerPorId(id) {
    const [eventos] = await db.query('SELECT * FROM eventos WHERE id = ?', [id]);
    return eventos[0];
  }

  async actualizar(id, datos) {
    // Verificar si el evento existe
    const eventoExistente = await this.obtenerPorId(id);
    if (!eventoExistente) {
      throw new Error('Evento no encontrado');
    }
  
    // Validar los datos (si es necesario)
    const valores = {
      tipo_evento: datos.tipo_evento,
      nombre_evento: datos.nombre_evento,
      nombre_cliente: datos.nombre_cliente,
      fecha: datos.fecha,
      hora: datos.hora,
      detalles: datos.detalles,
      asistentes: datos.asistentes,
      creado_en: datos.creado_en
    };
  
    // Actualizar los valores en la base de datos
    await db.query('UPDATE eventos SET ? WHERE id = ?', [valores, id]);
  }
  
  

  async eliminar(id) {
    // Verificar si el evento existe
    const eventoExistente = await this.obtenerPorId(id);
    if (!eventoExistente) {
      throw new Error('Evento no encontrado');
    }
  
    // Eliminar el evento
    await db.query('DELETE FROM eventos WHERE id = ?', [id]);
  }
  
}

module.exports = new EventoRepository();
