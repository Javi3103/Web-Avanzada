class Evento {
    constructor(id, tipo_evento, nombre_evento, nombre_cliente, fecha, hora, detalles, asistentes, creado_en) {
      this.id = id;
      this.tipo_evento = tipo_evento;
      this.nombre_evento = nombre_evento;
      this.nombre_cliente = nombre_cliente;
      this.fecha = fecha;
      this.hora = hora;
      this.detalles = detalles;
      this.asistentes = asistentes;
      this.creado_en = creado_en;
    }
  }
  
  module.exports = Evento;
  