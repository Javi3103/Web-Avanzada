const express = require('express');
const EventoController = require('../controllers/evento.controller');
const router = express.Router();

router.get('/', EventoController.obtenerTodas);
router.post('/', EventoController.crear); // Debe existir esta ruta
router.get('/:id', EventoController.obtenerPorId);
router.put('/:id', EventoController.actualizar);
router.delete('/:id', EventoController.eliminar);

module.exports = router;
