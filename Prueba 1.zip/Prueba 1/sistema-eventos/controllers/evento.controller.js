const EventoService = require('../services/evento.services');

class EventoController {
  async obtenerTodas(req, res) {
    const eventos = await EventoService.obtenerTodas();
    res.json(eventos);
  }

  async crear(req, res) {
    try {
      // Asegúrate de que el JSON enviado tenga un array llamado "eventos"
      if (!req.body.eventos || !Array.isArray(req.body.eventos) || req.body.eventos.length === 0) {
        return res.status(400).json({ error: 'Formato de datos inválido o vacío' });
      }

      const evento = req.body.eventos[0]; // Extraer el primer objeto del array
      
      // Validar campos esenciales
      const camposRequeridos = ['tipo_evento', 'nombre_evento', 'nombre_cliente', 'fecha', 'hora'];
      for (const campo of camposRequeridos) {
        if (!evento[campo]) {
          return res.status(400).json({ error: `El campo '${campo}' es requerido` });
        }
      }

      // Llamar al servicio con los datos válidos
      const id = await EventoService.crear(evento);
      res.status(201).json({ message: 'Evento creado', id });
    } catch (error) {
      console.error('Error al crear el evento:', error.message);
      res.status(500).json({ error: 'Error interno al crear el evento' });
    }
  }

  async obtenerPorId(req, res) {
    const evento = await EventoService.obtenerPorId(req.params.id);
    if (!evento) {
      return res.status(404).json({ mensaje: 'Evento no encontrado' });
    }
    res.json(evento);
  }

  async actualizar(req, res) {
    try {
      // Verificar si el evento existe
      const eventoExistente = await EventoService.obtenerPorId(req.params.id);
      if (!eventoExistente) {
        return res.status(404).json({ error: 'Evento no encontrado' });
      }
  
      // Validar que el cuerpo de la solicitud tenga los datos necesarios
      const evento = req.body;
      const camposRequeridos = ['tipo_evento', 'nombre_evento', 'nombre_cliente', 'fecha', 'hora'];
      for (const campo of camposRequeridos) {
        if (!evento[campo]) {
          return res.status(400).json({ error: `El campo '${campo}' es requerido` });
        }
      }
  
      // Llamar al servicio para actualizar
      await EventoService.actualizar(req.params.id, evento);
      res.json({ mensaje: 'Evento actualizado' });
    } catch (error) {
      console.error('Error al actualizar el evento:', error.message);
      res.status(500).json({ error: 'Error interno al actualizar el evento' });
    }
  }
  
  async eliminar(req, res) {
    try {
      // Verificar si el evento existe
      const eventoExistente = await EventoService.obtenerPorId(req.params.id);
      if (!eventoExistente) {
        return res.status(404).json({ error: 'Evento no encontrado' });
      }
  
      // Llamar al servicio para eliminar
      await EventoService.eliminar(req.params.id);
      res.json({ mensaje: 'Evento eliminado' });
    } catch (error) {
      console.error('Error al eliminar el evento:', error.message);
      res.status(500).json({ error: 'Error interno al eliminar el evento' });
    }
  }
 
}

module.exports = new EventoController();
