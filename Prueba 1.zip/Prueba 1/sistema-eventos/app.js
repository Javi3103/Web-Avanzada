require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const eventosRouter = require('./routes/evento.routes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware para permitir la lectura de JSON con un tamaño máximo de 50mb
app.use(bodyParser.json({ limit: '50mb' }));

// Manejo de errores si el cuerpo JSON no es válido
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError) {
    console.error('Error de sintaxis JSON:', err);
    return res.status(400).json({ error: 'Formato JSON inválido' });
  }
  next();
});

// Rutas
app.use('/api/eventos', eventosRouter);

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
