const EventoRepository = require('../repositories/evento.repository');

class EventoService {
  async obtenerTodas() {
    return await EventoRepository.obtenerTodas();
  }

  async crear(evento) {
    return await EventoRepository.crear(evento);
  }

  async obtenerPorId(id) {
    return await EventoRepository.obtenerPorId(id);
  }

  async actualizar(id, datos) {
    return await EventoRepository.actualizar(id, datos);
  }

  async eliminar(id) {
    return await EventoRepository.eliminar(id);
  }
}

module.exports = new EventoService();
